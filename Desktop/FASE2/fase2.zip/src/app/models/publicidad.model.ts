export interface Publicidad {
  id: string;
  title: string;
  content: string;
  active: boolean;
  createdAt: string;
}
